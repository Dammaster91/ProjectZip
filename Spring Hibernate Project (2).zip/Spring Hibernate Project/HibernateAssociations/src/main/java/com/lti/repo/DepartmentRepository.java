package com.lti.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lti.model.Department;

public interface DepartmentRepository extends JpaRepository<Department, Integer> {
}