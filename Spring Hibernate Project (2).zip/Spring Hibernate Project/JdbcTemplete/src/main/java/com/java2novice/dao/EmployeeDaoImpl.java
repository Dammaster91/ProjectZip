package com.java2novice.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.java2novice.model.Emp;

public class EmployeeDaoImpl implements EmployeeDao {

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public void insertEmployee(Emp emp) {

		String query = "insert into emp (id,name,salary,designation) values (?,?,?,?)";
		jdbcTemplate = new JdbcTemplate(dataSource);
		Object[] inputs = new Object[] { emp.getId(),emp.getName(), emp.getSalary(), emp.getDesignation() };
		jdbcTemplate.update(query, inputs);
	}
}