package com.java2novice.test;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.java2novice.dao.EmployeeDao;
import com.java2novice.model.Emp;

public class SpringDemo {

	public static void main(String a[]) {

		String confFile = "applicationContext.xml";
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext(confFile);
		EmployeeDao empDao = (EmployeeDao) context.getBean("employeeDAO");
		Emp emp = new Emp();
		emp.setId(3);
		emp.setName("Madhu");
		emp.setSalary(60000);
		emp.setDesignation("HR");
		empDao.insertEmployee(emp);
		System.out.println("insert");
	}
}