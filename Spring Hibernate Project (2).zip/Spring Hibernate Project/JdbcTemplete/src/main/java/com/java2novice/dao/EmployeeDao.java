package com.java2novice.dao;
 
import com.java2novice.model.Emp;
 
public interface EmployeeDao {
 
    public void insertEmployee(Emp emp);
}